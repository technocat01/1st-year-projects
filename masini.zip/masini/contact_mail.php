<?php
$toEmail = "elena.anghelina01@e-uvt.ro";
$mailHeaders = "From: " . $_POST["userName"] . "<". $_POST["userEmail"] .">\r\n";
if(mail($toEmail, $_POST["subject"], $_POST["content"], $mailHeaders)) {
print "<p class='success'>Mesajul a fost trimis!</p>";
} else {
print "<p class='Error'>Mesajul nu a fost trimis, va rugam reincercati!</p>";
}
?>