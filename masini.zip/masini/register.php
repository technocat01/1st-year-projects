<?php
// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$username = $password = $confirm_password = "";
$username_err = $password_err = $confirm_password_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Validate username
    if(empty(trim($_POST["username"]))){
        $username_err = "Vă rugăm să scrieți un nume";
    } elseif(!preg_match('/^[a-zA-Z0-9_]+$/', trim($_POST["username"]))){
        $username_err = "Numele membrului poate fi format doar din litere și cifre.";
    } else{
        // Prepare a select statement
        $sql = "SELECT id FROM users WHERE username = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = trim($_POST["username"]);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                /* store result */
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $username_err = "Acest nume este deja folosit, alegeți altul";
                } else{
                    $username = trim($_POST["username"]);
                }
            } else{
                echo "Va rugam sa incercati mai tarziu!";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Validate password
    if(empty(trim($_POST["password"]))){
        $password_err = "Vă rugăm scrieți o parolă";     
    } elseif(strlen(trim($_POST["password"])) < 6){
        $password_err = "Parola trebuie să aibă minim 6 caractere";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate confirm password
    if(empty(trim($_POST["confirm_password"]))){
        $confirm_password_err = "Confirmați parola";     
    } else{
        $confirm_password = trim($_POST["confirm_password"]);
        if(empty($password_err) && ($password != $confirm_password)){
            $confirm_password_err = "Parola nu se potrivește";
        }
    }
    
    // Check input errors before inserting in database
    if(empty($username_err) && empty($password_err) && empty($confirm_password_err)){
        
        // Prepare an insert statement
        $sql = "INSERT INTO users (username, password) VALUES (?, ?)";
         
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ss", $param_username, $param_password);
            
            // Set parameters
            $param_username = $username;
            $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Redirect to login page
                header("location: login.php");
            } else{
                echo "Va rugam sa incercati mai tarziu!";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Close connection
    mysqli_close($link);
}
?>
<!DOCTYPE html>
<html lang="ro-RO">
<head>
<title>Inregistrare</title>
<meta charset="UTF-8">	
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="site">

	<div class="header"><div class="headerin">
	<div class="headercm mobil"><img src="img/tel-1.png" /> 09887.654.325 &nbsp;&nbsp;&nbsp;&nbsp;<img src="img/mail-1.png" /> elena.anghelina01@e-uvt.ro</div>
	<div class="logo"><a href="index.html"><img src="img/logo_muzeu.png" /></a></div>
	<div class="headerdrm mobil"><div class="dropdown">
  <button class="dropbtn">MENIU</button>
  <div class="dropdown-content">
    <a href="index.html" title="Muzeul masinilor">HOME</a>
    <a href="masini.php" title="MUZEUL">MUZEU</a>
    <a href="contact.html" title="Contactati-ne!" class="last">CONTACT</a>
  </div>
</div></div>
	<div class="headerdr desktop">
	<div class="headerc"><img src="img/tel-1.png" /> 09887.654.325 &nbsp;&nbsp;&nbsp;&nbsp;<img src="img/mail-1.png" /> elena.anghelina01@e-uvt.ro</div>
	<div class="meniu"><a href="index.html" title="Muzeul masinilor">HOME</a><a href="masini.php" title="Masinile din muzeu">MUZEU</a><a href="contact.html" title="Contactati-ne!" class="last">CONTACT</a></div>
	</div>
	</div>
	</div>

	<h1 class="titlu">- ÎNREGISTRARE -</h1>
<div class="continut centru">
<p>COMPLETATI RUBRICILE DE MAI JOS PENTRU CREAREA UNUI CONT DE MEMBRU</p>

 <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
               <label>Nume membru</label><br><span class="invalid-feedback"><?php echo $username_err; ?></span>
                <input type="text" name="username" class="form-control <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>">
                
            </div>    
            <div class="form-group">
                <label>Parola</label><br><span class="invalid-feedback"><?php echo $password_err; ?></span>
                <input type="password" name="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $password; ?>">
                
            </div>
            <div class="form-group">
               <label>Confirmare parolă</label><br><span class="invalid-feedback"><?php echo $confirm_password_err; ?></span>
                <input type="password" name="confirm_password" class="form-control <?php echo (!empty($confirm_password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $confirm_password; ?>">
                
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Înregistrare">
                <input type="reset" class="btn btn-secondary ml-2" value="Resetare">
            </div>
            <p>Deja sunteți membru? <a href="login.php">Click aici pentru logare!</a>.</p>
        </form>



</div>
</div>
<div class="footer">
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d178.41675727250092!2d23.80166904815454!3d44.3167729163416!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4752d70a98a7a3ff%3A0x72a588734c8a6e2e!2sStrada%20Arie%C8%99%203%2C%20Craiova%20200384!5e0!3m2!1sen!2sro!4v1621460110711!5m2!1sen!2sro" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
</div>
<div class="footerj"><div class="footerjst">© 2021 | Muzeul masinilor</div><div class="footerjdr">Gabriela Anghelina anul 1 Informatica Romana</div></div>
</div>
</body>
</html>