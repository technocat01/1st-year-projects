<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}

require_once "config.php";
?>
<!DOCTYPE html>
<html lang="ro-RO">
<head>
<title>Muzeul de masini</title>
<meta charset="UTF-8">	
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css">
<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
</head>
<body>
<div class="site">

	<div class="header"><div class="headerin">
	<div class="headercm mobil"><img src="img/tel-1.png" /> 09887.654.325 &nbsp;&nbsp;&nbsp;&nbsp;<img src="img/mail-1.png" /> elena.anghelina01@e-uvt.ro</div>
	<div class="logo"><a href="index.html"><img src="img/logo_muzeu.png" /></a></div>
	<div class="headerdrm mobil"><div class="dropdown">
  <button class="dropbtn">MENIU</button>
  <div class="dropdown-content">
    <a href="index.html" title="Muzeul masinilor">HOME</a>
    <a href="#" title="MUZEUL">MUZEU</a>
    <a href="contact.html" title="Contactati-ne!" class="last">CONTACT</a>
  </div>
</div></div>
	<div class="headerdr desktop">
	<div class="headerc"><img src="img/tel-1.png" /> 09887.654.325 &nbsp;&nbsp;&nbsp;&nbsp;<img src="img/mail-1.png" /> elena.anghelina01@e-uvt.ro</div>
	<div class="meniu"><a href="index.html" title="Muzeul masinilor">HOME</a><a href="#" title="Masinile din muzeu">MUZEU</a><a href="contact.html" title="Contactati-ne!" class="last">CONTACT</a></div>
	</div>
	</div>
	</div>

	<h1 class="titlu">- MUZEUL -</h1>
<div class="continut">
<?php

// Attempt select query execution
$sql = "SELECT * FROM masini";
if($result = mysqli_query($link, $sql)){
    if(mysqli_num_rows($result) > 0){
        while($row = mysqli_fetch_array($result)){
                echo "<h1 class='titlucar'>" . $row['nume'] . "</h1>";
                echo "<p class='textcar'>" . $row['descriere'] . "</p>";

        }

        // Free result set
        mysqli_free_result($result);
    } else{
        echo "No records matching your query were found.";
    }
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>
</div>
</div>
<div class="footer">
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d178.41675727250092!2d23.80166904815454!3d44.3167729163416!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4752d70a98a7a3ff%3A0x72a588734c8a6e2e!2sStrada%20Arie%C8%99%203%2C%20Craiova%20200384!5e0!3m2!1sen!2sro!4v1621460110711!5m2!1sen!2sro" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
</div>
<div class="footerj"><div class="footerjst">© 2021 | Muzeul masinilor</div><div class="footerjdr">Gabriela Anghelina anul 1 Informatica Romana</div></div>
</div>
</body>
</html>