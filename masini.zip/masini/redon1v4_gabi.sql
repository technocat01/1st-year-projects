-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Gazdă: localhost:3306
-- Timp de generare: mai 20, 2021 la 08:33 PM
-- Versiune server: 10.3.28-MariaDB
-- Versiune PHP: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Bază de date: `redon1v4_gabi`
--

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `masini`
--

CREATE TABLE `masini` (
  `id` int(11) NOT NULL,
  `nume` varchar(50) NOT NULL,
  `descriere` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Eliminarea datelor din tabel `masini`
--

INSERT INTO `masini` (`id`, `nume`, `descriere`) VALUES
(1, 'FORD F-150 Raptor ', 'Ford released the third generation of the F150 Raptor in 2021 as a 2022 model year, and it was meaner and hard-core than before. In 2009, Ford stunned the world with the introduction of the Raptor\'s first generation. It was praised for its high-speed off-road abilities. Soon, the competition started to match its performances and caught-up.'),
(2, 'FORD Escape ', 'Ford Escape was the pioneer of the hybrid SUV back in 2005 and with the new generation it intends to go further with the engineering, performance and ecology improvements. The promise is, also, that this third generation is more fun to drive than ever. Under the hood Ford installed new units in compliance with the strictest, newest regulations but also with good performance.'),
(3, 'FORD Explorer ', 'The sixth generation of the Ford Explorer was launched at the North American Motor Show in 2019 and it shared its platform with the Lincoln Aviator. It represented the return to the RWD platform. The original Ford Explorer was launched in 1991 and it replaced the two-door Bronco II model. Its name came from a trim-package used for the F-Series between 1967 and 1986.');

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Eliminarea datelor din tabel `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `created_at`) VALUES
(1, 'gigel', '$2y$10$p42rNiIV8NRNdQc63CSEB.hrFScx3qTzOhrvD2HZMaTcI56aphSNS', '2021-05-20 18:15:24'),
(2, 'ion', '$2y$10$qQUm3sVCMPrYkYUJhTiwoOalYTTBq1/Q9yL0T8/USxdrhhkVpjulK', '2021-05-20 19:34:23');

--
-- Indexuri pentru tabele eliminate
--

--
-- Indexuri pentru tabele `masini`
--
ALTER TABLE `masini`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nume` (`nume`);

--
-- Indexuri pentru tabele `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT pentru tabele eliminate
--

--
-- AUTO_INCREMENT pentru tabele `masini`
--
ALTER TABLE `masini`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pentru tabele `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
